// Client‑side JavaScript for the Recipe Recommender app.
//
// When the user clicks the "Find Recipes" button, this script reads the
// ingredients and diet preference, constructs an API request to the backend
// server, and then renders the returned recipes in the results grid. It
// gracefully handles errors and displays helpful feedback messages.

const searchBtn = document.getElementById("searchBtn");
const results = document.getElementById("results");
const feedback = document.getElementById("feedback");

searchBtn.addEventListener("click", getRecipes);

/**
 * Determine the correct base URL for API calls. When running locally via
 * `npm start` and serving the frontend separately (e.g. on port 3000), the
 * backend is on http://localhost:8888. In production (e.g. Netlify), the
 * backend is proxied under the same origin, so no hostname is needed.
 *
 * @returns {string} The base URL (either '' for production or 'http://localhost:8888' for local dev)
 */
function getApiBase() {
  const host = window.location.hostname;
  // Check for localhost or 127.0.0.1 for local development
  const isLocal = host === "localhost" || host === "127.0.0.1";
  return isLocal ? "http://localhost:8888" : "";
}

/**
 * Fetch recipes from the API based on the user's input and update the UI.
 */
async function getRecipes() {
  // Clear previous results and messages
  results.innerHTML = "";
  feedback.textContent = "";

  const ingredients = document.getElementById("ingredients").value.trim();
  const diet = document.getElementById("diet").value;

  if (!ingredients) {
    feedback.textContent = "Please enter at least one ingredient.";
    return;
  }

  feedback.textContent = "Searching recipes...";

  // Construct the query string
  const base = getApiBase();
  const queryParams = new URLSearchParams();
  queryParams.set("ingredients", ingredients);
  if (diet) queryParams.set("diet", diet);
  const url = `${base}/api/recipes?${queryParams.toString()}`;

  try {
    const resp = await fetch(url);
    const data = await resp.json();

    if (!resp.ok) {
      // Show server error messages when available
      feedback.textContent = data.error || "No recipes found.";
      return;
    }

    // If the API includes a notice (e.g., fallback scenario), display it
    if (data.notice) {
      feedback.textContent = data.notice;
    } else if (!data.results || data.results.length === 0) {
      feedback.textContent = "No matching recipes found.";
      return;
    } else {
      feedback.textContent = `Found ${data.results.length} recipes.`;
    }

    renderResults(data.results);
  } catch (err) {
    console.error(err);
    feedback.textContent =
      "Failed to fetch recipes. Please check your connection or try again later.";
  }
}

/**
 * Render a list of recipe objects into the results container. Each recipe
 * includes an image, title, optional category/area, match score, and a
 * collapsible instructions section.
 *
 * @param {Array<Object>} list The array of recipe objects from the API
 */
function renderResults(list) {
  results.innerHTML = "";
  list.forEach((r) => {
    const card = document.createElement("article");
    card.className = "card";
    card.innerHTML = `
      <img src="${r.thumbnail || r.strMealThumb}" alt="Photo of ${escapeHtml(
        r.name || r.strMeal
      )}" />
      <h3>${escapeHtml(r.name || r.strMeal)}</h3>
      <p class="small">${escapeHtml(r.category || r.strCategory || "")} · ${escapeHtml(
        r.area || r.strArea || ""
      )}</p>
      ${typeof r.score === "number" ? `<p>Match Score: <strong>${r.score}</strong></p>` : ""}
      <details>
        <summary>Instructions</summary>
        <p>${escapeHtml(
          (r.instructions || r.strInstructions || "No instructions available.").slice(
            0,
            800
          )
        )}</p>
      </details>
    `;
    results.appendChild(card);
  });
}

/**
 * Escape HTML special characters to prevent injection vulnerabilities.
 *
 * @param {string} s The string to escape
 * @returns {string}
 */
function escapeHtml(s) {
  if (!s) return "";
  return String(s).replace(/[&<>"']/g, (m) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[m]);
}