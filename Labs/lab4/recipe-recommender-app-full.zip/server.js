// Simple HTTP server that serves the frontend and provides the /api/recipes
// endpoint without any external dependencies. This file is provided for
// convenience when running the project locally on systems that cannot
// install npm packages. It combines the API and the static site into one
// process.
//
// Usage: node server.js

import http from 'http';
import { readFile } from 'fs/promises';
import { existsSync, createReadStream } from 'fs';
import { extname, join, resolve } from 'path';

// Directory where the frontend assets live
const FRONTEND_DIR = resolve('frontend');

// Compute a simple match score based on matching ingredients
function computeMatchScore(meal, ingList) {
  const mealIngredients = [];
  for (let i = 1; i <= 20; i++) {
    const key = `strIngredient${i}`;
    const value = meal[key];
    if (value) {
      mealIngredients.push(String(value).toLowerCase());
    }
  }
  let score = 0;
  ingList.forEach((q) => {
    if (mealIngredients.some((mi) => mi.includes(q) || q.includes(mi))) {
      score++;
    }
  });
  return score;
}

async function fetchMealDetails(idMeal) {
  const resp = await fetch(
    `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${idMeal}`
  );
  if (!resp.ok) return null;
  const data = await resp.json();
  return data.meals ? data.meals[0] : null;
}

async function handleApi(req, res, url) {
  const ingredients = url.searchParams.get('ingredients') || '';
  const diet = url.searchParams.get('diet') || '';
  const ingList = ingredients
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  if (ingList.length === 0) {
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(
      JSON.stringify({
        error: 'Please provide at least one ingredient using ?ingredients=egg,tomato',
      })
    );
    return;
  }
  // Fetch meals filtered by the first ingredient
  const first = encodeURIComponent(ingList[0]);
  let meals;
  let notice = '';
  try {
    const filterResp = await fetch(
      `https://www.themealdb.com/api/json/v1/1/filter.php?i=${first}`
    );
    const filterData = await filterResp.json();
    meals = filterData.meals;
    if (!meals) {
      const randomResp = await fetch(
        'https://www.themealdb.com/api/json/v1/1/search.php?s='
      );
      const randomData = await randomResp.json();
      meals = randomData.meals.slice(0, 8);
      notice =
        'No exact matches found. Showing random recipes instead. Try another ingredient for more accurate results.';
    }
    const detailPromises = meals.slice(0, 8).map((m) => fetchMealDetails(m.idMeal));
    const detailed = (await Promise.all(detailPromises)).filter(Boolean);
    const results = detailed.map((meal) => {
      const score = computeMatchScore(meal, ingList);
      return {
        id: meal.idMeal,
        name: meal.strMeal,
        category: meal.strCategory,
        area: meal.strArea,
        thumbnail: meal.strMealThumb,
        instructions: meal.strInstructions,
        ingredients: Array.from({ length: 20 })
          .map((_, i) => meal[`strIngredient${i + 1}`])
          .filter(Boolean),
        score,
      };
    });
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ queryIngredients: ingList, notice, results }));
  } catch (err) {
    console.error('API error', err);
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Server error' }));
  }
}

function getMimeType(filePath) {
  const ext = extname(filePath).toLowerCase();
  switch (ext) {
    case '.html':
      return 'text/html';
    case '.js':
      return 'application/javascript';
    case '.css':
      return 'text/css';
    case '.png':
      return 'image/png';
    case '.jpg':
    case '.jpeg':
      return 'image/jpeg';
    case '.svg':
      return 'image/svg+xml';
    case '.json':
      return 'application/json';
    default:
      return 'application/octet-stream';
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    // API route
    if (url.pathname === '/api/recipes') {
      await handleApi(req, res, url);
      return;
    }
    // Serve static files from the frontend directory
    let filePath;
    if (url.pathname === '/' || url.pathname === '/index.html') {
      filePath = join(FRONTEND_DIR, 'index.html');
    } else {
      // Prevent directory traversal
      const safePath = url.pathname.replace(/\.\./g, '');
      filePath = join(FRONTEND_DIR, safePath);
    }
    if (existsSync(filePath)) {
      const mimeType = getMimeType(filePath);
      res.writeHead(200, { 'Content-Type': mimeType });
      const stream = createReadStream(filePath);
      stream.pipe(res);
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not Found');
    }
  } catch (err) {
    console.error(err);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('Internal Server Error');
  }
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/`);
});